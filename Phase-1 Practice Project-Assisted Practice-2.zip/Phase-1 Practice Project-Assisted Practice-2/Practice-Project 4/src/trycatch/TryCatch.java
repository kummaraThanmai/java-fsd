package trycatch;
import java.util.*;


public class TryCatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int data = 100/0;
		}
		catch(ArithmeticException e) {
			System.out.println("arthematic Exception");
			
		}
		finally {
		System.out.println("rest of the code");

	}

}
}
