package fileoperations;

import java.io.File;

public class FileDelete {

	public static void main(String[] args) {
		File myFile2 = new File("data2.txt");
		if(myFile2.delete()) {
			System.out.println("File deleted "+myFile2.getName()+"successfully");
		}
		else {
			System.out.println("Failed to delete a File");
		}

	}

}
