package threadrunnable;

public class Single implements Runnable {
	public void run() {
		for(int i=0;i<=5;i++){ 
			System.out.println(i);
		}
	}	

}
class main1{
public static void main(String[] args) {
	// TODO Auto-generated method stub
	Single s =new Single();
	Thread t = new Thread(s);
	t.start();

}
}
