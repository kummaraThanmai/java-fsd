package exceptionthrows;
import java.util.*;

public class throwsex {

	 public int division(int a,int b) throws ArithmeticException{
		int result =a/b;
		return result;
	}

}
class main{
public static void main(String[] args) {
	throwsex obj1 = new throwsex();
	try {
		System.out.println(obj1.division(15, 0));
		
	}
	catch(ArithmeticException e){
		System.out.println("division cannot be done using zero");
		
	}
	finally {
		System.out.println("program ended");
	}
	
	
}
}
