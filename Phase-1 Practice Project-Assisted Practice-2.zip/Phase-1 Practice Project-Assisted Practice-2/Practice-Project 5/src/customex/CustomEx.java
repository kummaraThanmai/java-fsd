package customex;

public class CustomEx extends Exception {
	public CustomEx(String s) 
    { 
        super(s); 
    } 

	
}

 class Tester  {
	 public static void main(String args[])  
	    {  
	        try  
	        {  
	            // throw an object of user defined exception  
	            throw new CustomEx( "new");  
	        }  
	        catch (CustomEx ex)  
	        {  
	            System.out.println("Caught the exception");  
	            System.out.println(ex.getMessage());  
	        }  
	  
	        System.out.println("end of the code");    
	    } 
}

