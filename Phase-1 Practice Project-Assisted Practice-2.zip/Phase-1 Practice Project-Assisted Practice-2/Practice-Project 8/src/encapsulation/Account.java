package encapsulation;

class Account {
	private long acc_no;
	private String name;
	private String email;
	private float amount;

	
	public long getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(long acc_no) {
		this.acc_no = acc_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
}
class TestEncapsulation{
public static void main(String[] args) {
	// TODO Auto-generated method stub
	Account ac = new Account();
	ac.setAcc_no(75645654677L);
	ac.setName("adhya");
	ac.setEmail("adhya@gmail.com");
	ac.setAmount(70000f);
	System.out.println(ac.getEmail()+" "+ac.getAcc_no()+" "+ac.getName()+ " "+ac.getAmount());

}
}

