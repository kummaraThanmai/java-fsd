package polymorphism;

public class calculation {
	//method overloading
	public int mul(int a, int b) {
		return a*b;
	}
	public int mul(int a, int b,int c) {
		return a*b*c;
	}
		void hello() {
		System.out.println("good morning-base class");
		
	}
	
}
//method overriding
class wishes extends calculation{
	void hello() {
		System.out.println("good evening-derived class");
	}
}


class main{
public static void main(String[] args) {
	// TODO Auto-generated method stub
	calculation c = new calculation();
	System.out.println(c.mul(2, 4));
	System.out.println(c.mul(2,2,3));
	c.hello(); //method overriding
	wishes w = new wishes();
	w.hello();
	calculation cw = new wishes();
	cw.hello();
	
	

}
}

