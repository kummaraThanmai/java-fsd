package inheritance;

public class Animal {
	
void eat() {
	System.out.println("eating--parent class");
}

}
class Dog extends Animal{
	void bark() {
		
	System.out.println("barking--child class");
	}
	
}

class tester{
public static void main(String[] args) {
	// TODO Auto-generated method stub
	Dog d =new Dog();
	d.bark();
	d.eat();
	

}
}
