package classesandobject;

public class student {
	int id;
	String name;
}

class tester{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student s1 = new student();
		student s2 = new student();
		s1.id = 101;
		s1.name ="adithi";
		System.out.println(s1.id+" "+s1.name);
		s2.id = 102;
		s2.name ="adi";
		System.out.println(s2.id+" "+s2.name);
		
	}
}


