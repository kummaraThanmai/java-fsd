package sleepwaitex;

public class sleepwaitex {
	
	
	  
	    //create an instance of the Object   
	    private static Object obj = new Object();   
	  
	  
	    public static void main(String[] args)throws InterruptedException   
	    {   
	          
	        //pause process for two second  
	        Thread.sleep(2000);   
	          
	        //print custom statement  
	        System.out.println( Thread.currentThread().getName() +   
	        " Thread is woken after 2 second");   
	          
	        //create synchronizec context from which we call Wait() method  
	        synchronized (obj)    
	        {   
	            //use wailt() method to set obj in waiting state for two seconds  
	            obj.wait(5000);   
	  
	            System.out.println(obj + " Object is in waiting state and woken after 5 seconds");   
	        }   
	    }   
	}

	


