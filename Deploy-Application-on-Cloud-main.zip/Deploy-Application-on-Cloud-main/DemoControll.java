package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class DemoControll {
	@ResponseBody
	@RequestMapping("/display")
	private String display() {
		return "hii leaners welcome to AWS";
		
	}
}


